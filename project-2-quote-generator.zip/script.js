const quotes = [
  { q: "Small steps everyday lead to massive achievements.", a: "Anonymous" },
  { q: "Code is like humor. When you have to explain it, it’s bad.", a: "Cory House" },
  { q: "First, solve the problem. Then, write the code.", a: "John Johnson" },
  { q: "Experience is the name everyone gives to their mistakes.", a: "Oscar Wilde" },
  { q: "Simplicity is the soul of efficiency.", a: "Austin Freeman" }
];

function nextQuote() {
  const random = quotes[Math.floor(Math.random() * quotes.length)];
  document.getElementById('quote').textContent = '"' + random.q + '"';
  document.getElementById('author').textContent = '- ' + random.a;
}